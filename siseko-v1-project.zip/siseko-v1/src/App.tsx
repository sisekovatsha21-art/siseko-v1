import { useEffect, useMemo, useState } from 'react';
import { Activity, Bell, BookOpen, Gauge, LayoutDashboard, Radio, Settings, ShieldAlert, Wifi, WifiOff } from 'lucide-react';
import { MARKETS, analyze } from './engine/scanner';
import type { MarketData } from './services/marketData';
import { getMarketData } from './services/marketData';
import type { Signal, SymbolName } from './engine/types';

const money=(v:number|null)=>v===null?'—':v.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:5});

export function App(){
  const [selected,setSelected]=useState<SymbolName>('BTCUSD');
  const [data,setData]=useState<MarketData|null>(null);
  const [lastScan,setLastScan]=useState<number|null>(null);
  const [signal,setSignal]=useState<Signal>(()=>analyze('BTCUSD',{},false));
  const [tab,setTab]=useState('Command');
  const [risk,setRisk]=useState(0.5);
  const [auto,setAuto]=useState(true);

  useEffect(()=>{
    let cancelled=false;
    const load=async()=>{
      try{ const d=await getMarketData(selected); if(cancelled)return; setData(d); setSignal(analyze(selected,d.frames,d.live)); setLastScan(Date.now()); }
      catch{ if(!cancelled){ setData({symbol:selected,live:false,frames:{},price:null,change24h:null}); setSignal(analyze(selected,{},false)); setLastScan(Date.now()); }}
    };
    load();
    const id=auto?window.setInterval(load,15000):undefined;
    return()=>{cancelled=true;if(id)window.clearInterval(id)};
  },[selected,auto]);

  const status = data?.live ? 'ONLINE' : 'OFFLINE';
  const cards=useMemo(()=>MARKETS.map(m=>({m,active:m==='BTCUSD'})),[]);

  return <div className="shell">
    <header className="topbar">
      <div><div className="brand">SISEKO V1</div><div className="subtitle">MARKET INTELLIGENCE SYSTEM</div></div>
      <div className={`status ${status==='ONLINE'?'online':'offline'}`}><span className="dot"/>{status==='ONLINE'?'SCANNER ONLINE':'DATA OFFLINE'}</div>
    </header>

    <main>
      <section className="hero">
        <div><div className="eyebrow">CREATOR / MENTOR</div><h1>SISEKO TEDROSSY VATSHA</h1><p>Manual execution only • Demo trading & analysis • No automatic orders</p></div>
        <div className="live-pill"><Radio size={15}/> {data?.live?'LIVE FEED':'WAITING FOR DATA'}</div>
      </section>

      <section className="market-strip">{cards.map(({m,active})=><button key={m} onClick={()=>setSelected(m)} className={`market-card ${m===selected?'selected':''}`}><span>{m}</span><small>{active?'BINANCE':'NOT CONNECTED'}</small><b>{m===selected&&data?.price?money(data.price):'—'}</b></button>)}</section>

      <div className="grid">
        <section className="panel signal-panel">
          <div className="panel-head"><div><div className="eyebrow">CURRENT STATE</div><h2>{signal.state}</h2></div><Activity/></div>
          <div className="scan-row"><span>{selected}</span><strong>{signal.htfBias}</strong><span>Last scan {lastScan?new Date(lastScan).toLocaleTimeString():'—'}</span></div>
          <div className="hierarchy">{(['H4','H1','M15','M5'] as const).map(tf=><div key={tf}><small>{tf}</small><strong>{signal.htfBias}</strong></div>)}</div>
          <div className="metric-grid">
            <Metric k="LIQUIDITY EVENT" v={signal.liquidityEvent}/><Metric k="STRUCTURE" v={signal.structure}/><Metric k="DISPLACEMENT" v={signal.displacement}/><Metric k="FVG" v={signal.fvg}/><Metric k="ORDER BLOCK" v={signal.orderBlock}/><Metric k="EMA STATUS" v={signal.emaStatus}/><Metric k="RSI" v={signal.rsi===null?'—':signal.rsi.toFixed(1)}/><Metric k="ATR" v={signal.atr===null?'—':money(signal.atr)}/>
          </div>
          <div className="levels"><Level name="ENTRY" value={signal.entry}/><Level name="STOP LOSS" value={signal.stopLoss}/><Level name="TAKE PROFIT 1" value={signal.takeProfit1}/><Level name="TAKE PROFIT 2" value={signal.takeProfit2}/></div>
          <div className="summary"><div><span>SETUP SCORE</span><b>{signal.setupScore}/100</b></div><div><span>RISK / REWARD</span><b>{signal.riskReward?`${signal.riskReward.toFixed(2)}R`:'—'}</b></div><div><span>NEWS RISK</span><b>{signal.newsRisk}</b></div></div>
          <div className="reason"><div className="eyebrow">REASON FOR SIGNAL</div><p>{signal.reason}</p></div>
        </section>

        <aside className="side-stack">
          <section className="panel"><div className="panel-head"><h3>RISK CONTROL</h3><ShieldAlert/></div><label>Theoretical risk / setup <strong>{risk.toFixed(1)}%</strong></label><input type="range" min="0.5" max="1" step="0.1" value={risk} onChange={e=>setRisk(Number(e.target.value))}/><div className="risk-note">Never exceeds 1%. No automatic execution.</div></section>
          <section className="panel"><div className="panel-head"><h3>SCANNER LOOP</h3><Gauge/></div><button className={`toggle ${auto?'on':''}`} onClick={()=>setAuto(v=>!v)}><span/>{auto?'CONTINUOUS CLIENT SCAN':'SCANNER PAUSED'}</button><p className="muted">A true 24/7 scanner requires persistent hosting. This phone session only scans while the app is running.</p></section>
          <section className="panel"><div className="panel-head"><h3>CONNECTIONS</h3><Wifi/></div>{MARKETS.map(m=><div className="connection" key={m}><span>{m}</span>{m==='BTCUSD'?<><span className="ok">● LIVE</span><Wifi size={14}/></>:<><span className="bad">● OFFLINE</span><WifiOff size={14}/></>}</div>)}</section>
        </aside>
      </div>
    </main>

    <nav className="bottom-nav">{[['Command',LayoutDashboard],['Watchlist',Activity],['Alerts',Bell],['Journal',BookOpen],['Settings',Settings]].map(([name,Icon]:any)=><button key={name} className={tab===name?'active':''} onClick={()=>setTab(name)}><Icon size={18}/><span>{name}</span></button>)}</nav>
    <footer>SISEKO V1 • Manual analysis only • No fake data • No real trade execution</footer>
  </div>
}

function Metric({k,v}:{k:string,v:string}){return <div className="metric"><span>{k}</span><strong>{v}</strong></div>}
function Level({name,value}:{name:string,value:number|null}){return <div className="level"><span>{name}</span><strong>{value===null?'—':money(value)}</strong></div>}
