import type { Candle } from './types';

export const ema = (values:number[], period:number) => {
  if (values.length < period) return null;
  const k = 2 / (period + 1);
  let e = values.slice(0, period).reduce((a,b)=>a+b,0) / period;
  for (let i=period; i<values.length; i++) e = values[i] * k + e * (1-k);
  return e;
};

export const rsi = (candles:Candle[], period=14) => {
  if (candles.length <= period) return null;
  let gain = 0, loss = 0;
  for (let i=1;i<=period;i++) {
    const d = candles[i].close - candles[i-1].close;
    if (d >= 0) gain += d; else loss -= d;
  }
  let avgGain = gain/period, avgLoss = loss/period;
  for (let i=period+1;i<candles.length;i++) {
    const d = candles[i].close - candles[i-1].close;
    avgGain = ((avgGain*(period-1)) + Math.max(d,0))/period;
    avgLoss = ((avgLoss*(period-1)) + Math.max(-d,0))/period;
  }
  if (avgLoss === 0) return 100;
  return 100 - (100/(1 + avgGain/avgLoss));
};

export const atr = (candles:Candle[], period=14) => {
  if (candles.length <= period) return null;
  const tr:number[] = [];
  for (let i=1;i<candles.length;i++) {
    const c = candles[i], p = candles[i-1];
    tr.push(Math.max(c.high-c.low, Math.abs(c.high-p.close), Math.abs(c.low-p.close)));
  }
  let a = tr.slice(0,period).reduce((x,y)=>x+y,0)/period;
  for (let i=period;i<tr.length;i++) a=((a*(period-1))+tr[i])/period;
  return a;
};
