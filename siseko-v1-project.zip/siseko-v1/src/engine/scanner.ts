import type { Bias, Candle, Signal, SymbolName, Timeframe } from './types';
import { atr, ema, rsi } from './indicators';

export const MARKETS:SymbolName[] = ['XAUUSD','EURUSD','GBPUSD','USDJPY','NASDAQ','SP500','BTCUSD'];
export const HIERARCHY:Timeframe[] = ['H4','H1','M15','M5','M1'];

const hasDisplacement = (c:Candle, a:number|null) => Boolean(a && Math.abs(c.close-c.open) >= a*1.25);

export function analyze(market:SymbolName, frames:Partial<Record<Timeframe,Candle[]>>, live:boolean):Signal {
  if (!live) return offlineSignal(market);
  const h4=frames.H4||[], h1=frames.H1||[], m15=frames.M15||[], m5=frames.M5||[];
  const h4Close=h4.at(-1)?.close, h1Close=h1.at(-1)?.close, m5Close=m5.at(-1)?.close;
  const h4e20=h4.length?ema(h4.map(c=>c.close),20):null, h4e50=h4.length?ema(h4.map(c=>c.close),50):null;
  const h1e20=h1.length?ema(h1.map(c=>c.close),20):null, h1e50=h1.length?ema(h1.map(c=>c.close),50):null;
  const m5e20=m5.length?ema(m5.map(c=>c.close),20):null, m5e50=m5.length?ema(m5.map(c=>c.close),50):null;
  const rrsi=rsi(m5), aatr=atr(m5);
  let bias:Bias='NEUTRAL';
  if(h4Close && h4e20 && h4e50 && h1Close && h1e20 && h1e50) {
    if(h4Close>h4e20 && h4e20>h4e50 && h1Close>h1e20 && h1e20>h1e50) bias='BULLISH';
    else if(h4Close<h4e20 && h4e20<h4e50 && h1Close<h1e20 && h1e20<h1e50) bias='BEARISH';
  }
  const last=m5.at(-1);
  const prev=m5.at(-2);
  if(!last || !prev || !aatr || !m5e20 || !m5e50 || !rrsi) return offlineLikeWatch(market, live);
  const disp=hasDisplacement(last, aatr);
  const bullish = bias==='BULLISH' && m5e20>m5e50 && last.close>m5e20 && rrsi>=50 && rrsi<=70 && disp;
  const bearish = bias==='BEARISH' && m5e20<m5e50 && last.close<m5e20 && rrsi<=50 && rrsi>=30 && disp;
  const direction = bullish?'BUY':bearish?'SELL':'NONE';
  const state = direction==='NONE' ? (disp ? 'WATCHING' : 'NO TRADE') : 'BUY';
  const entry=last.close;
  const sl = direction==='BUY' ? Math.min(prev.low,last.low)-aatr*0.15 : direction==='SELL' ? Math.max(prev.high,last.high)+aatr*0.15 : null;
  const risk=sl===null?null:Math.abs(entry-sl);
  const tp1 = risk===null?null:(direction==='BUY'?entry+risk*1.5:entry-risk*1.5);
  const tp2 = risk===null?null:(direction==='BUY'?entry+risk*2.5:entry-risk*2.5);
  const rr = risk&&tp2 ? Math.abs(tp2-entry)/risk : null;
  const score = Math.min(100, 25 + (bias!=='NEUTRAL'?20:0) + (disp?15:0) + (m5e20>m5e50=== (direction==='BUY')?15:0) + ((rrsi>50)===(direction==='BUY')?10:0) + 15);
  return {
    market,direction,htfBias:bias,
    liquidityEvent:'Awaiting confirmed sweep model',
    structure:'Awaiting confirmed BOS/CHOCH model',
    displacement:disp?'CONFIRMED':'NOT CONFIRMED',
    fvg:'Awaiting 3-candle imbalance confirmation',
    orderBlock:'Awaiting validated order block',
    emaStatus:`EMA20 ${last.close>m5e20?'above':'below'} EMA50`,
    rsi:rrsi,atr:aatr,entry:direction==='NONE'?null:entry,stopLoss:direction==='NONE'?null:sl,
    takeProfit1:direction==='NONE'?null:tp1,takeProfit2:direction==='NONE'?null:tp2,
    riskReward:rr,setupScore:score,newsRisk:'UNKNOWN — live calendar adapter not connected',
    invalidationLevel:direction==='NONE'?null:sl,
    reason:direction==='BUY'?'HTF bullish alignment + momentum + displacement.':direction==='SELL'?'HTF bearish alignment + momentum + displacement.':'Conditions are incomplete; wait for independent SMC confluence.',
    state:direction==='BUY'?'BUY':direction==='SELL'?'SELL':state,
    generatedAt:Date.now(),dataStatus:'LIVE'
  };
}

export function offlineSignal(market:SymbolName):Signal { return {market,direction:'NONE',htfBias:'OFFLINE',liquidityEvent:'—',structure:'—',displacement:'—',fvg:'—',orderBlock:'—',emaStatus:'—',rsi:null,atr:null,entry:null,stopLoss:null,takeProfit1:null,takeProfit2:null,riskReward:null,setupScore:0,newsRisk:'OFFLINE',invalidationLevel:null,reason:'DATA CONNECTION: OFFLINE — no genuine live feed available for this market.',state:'NO TRADE',generatedAt:Date.now(),dataStatus:'OFFLINE'}; }
export function offlineLikeWatch(market:SymbolName, live:boolean):Signal { const s=offlineSignal(market); s.dataStatus=live?'LIVE':'OFFLINE'; s.htfBias=live?'NEUTRAL':'OFFLINE'; s.reason=live?'Live feed connected, but there is insufficient candle history for a validated setup.':'DATA CONNECTION: OFFLINE'; s.state=live?'WAITING':'NO TRADE'; return s; }
