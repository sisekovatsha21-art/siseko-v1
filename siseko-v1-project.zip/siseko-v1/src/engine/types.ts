export type SymbolName = 'XAUUSD'|'EURUSD'|'GBPUSD'|'USDJPY'|'NASDAQ'|'SP500'|'BTCUSD';
export type Timeframe = 'H4'|'H1'|'M15'|'M5'|'M1';
export type Bias = 'BULLISH'|'BEARISH'|'NEUTRAL'|'OFFLINE';
export type SignalState = 'BUY'|'SELL'|'NO TRADE'|'WATCHING';

export interface Candle { time:number; open:number; high:number; low:number; close:number; volume:number; }
export interface Signal {
  market: SymbolName;
  direction: 'BUY'|'SELL'|'NONE';
  htfBias: Bias;
  liquidityEvent: string;
  structure: string;
  displacement: string;
  fvg: string;
  orderBlock: string;
  emaStatus: string;
  rsi: number | null;
  atr: number | null;
  entry: number | null;
  stopLoss: number | null;
  takeProfit1: number | null;
  takeProfit2: number | null;
  riskReward: number | null;
  setupScore: number;
  newsRisk: string;
  invalidationLevel: number | null;
  reason: string;
  state: SignalState;
  generatedAt: number;
  dataStatus: 'LIVE'|'OFFLINE';
}
