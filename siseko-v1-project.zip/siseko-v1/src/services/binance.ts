import type { Candle } from '../engine/types';

const tfMap:Record<string,string>={M5:'5m',M15:'15m',H1:'1h',H4:'4h'};
export async function fetchBinance(symbol='BTCUSDT', timeframe='M5', limit=250):Promise<Candle[]> {
  const interval=tfMap[timeframe];
  if(!interval) throw new Error('Unsupported timeframe');
  const r=await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
  if(!r.ok) throw new Error(`Binance HTTP ${r.status}`);
  const rows=await r.json() as unknown[];
  return rows.map((row:any)=>({time:Number(row[0]),open:Number(row[1]),high:Number(row[2]),low:Number(row[3]),close:Number(row[4]),volume:Number(row[5])}));
}
