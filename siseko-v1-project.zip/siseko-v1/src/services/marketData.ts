import type { Candle, SymbolName, Timeframe } from '../engine/types';
import { fetchBinance } from './binance';

export interface MarketData { symbol:SymbolName; live:boolean; frames:Partial<Record<Timeframe,Candle[]>>; price:number|null; change24h:number|null; }

const offline=(symbol:SymbolName):MarketData=>({symbol,live:false,frames:{},price:null,change24h:null});

export async function getMarketData(symbol:SymbolName):Promise<MarketData>{
  if(symbol!=='BTCUSD') return offline(symbol);
  const [h4,h1,m15,m5]=await Promise.all(['H4','H1','M15','M5'].map(tf=>fetchBinance('BTCUSDT',tf)));
  const ticker=await fetch('https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT');
  const t=await ticker.json() as {lastPrice:string,priceChangePercent:string};
  return {symbol,live:true,frames:{H4:h4,H1:h1,M15:m15,M5:m5},price:Number(t.lastPrice),change24h:Number(t.priceChangePercent)};
}
